# WEBFLOW PORTFOLIO — Step 16.5 / Migrazione prudente

Questo pacchetto contiene una separazione FEDELE (senza riscrittura della logica)
dei moduli Step 14 / PLACES e Step 15 / TRAVEL JOURNAL gia' funzionanti.

Non contiene il codice effettivo degli Step 1–13: quelle implementazioni sono
dentro il tuo progetto Webflow e devono essere recuperate prima di un refactor completo.
Step 16 / foto e' presente ma OPZIONALE, non va attivato finche' non decidi
di usarlo: non era ancora stato installato quando abbiamo iniziato la migrazione.

STRUTTURA
- webflow-html/places_solo_html.txt: SOLO markup, non contiene JS/CSS
- webflow-html/journal_solo_html.txt: SOLO markup, non contiene JS/CSS
- assets/css/places.css; journal.css: CSS estratto da Step 14 e Step 15
- assets/js/places.js; journal.js: JS estratto senza modifiche
- assets/css/photos_optional.css e assets/js/photos_optional.js: codice foto Step 16 (NON ATTIVARE)
- originali/*: copie integrali dei tre file originari
- istruzioni/LINK_CSS_HEAD.txt: snippet con URL di esempio DA PERSONALIZZARE
- istruzioni/SCRIPT_FOOTER.txt: snippet con URL di esempio DA PERSONALIZZARE

FASE 0 — BACKUP OBBLIGATORIO
- In Webflow Designer aspetta "Changes saved" e usa Ctrl+Shift+S.
- Descrizione consigliata: "Prima refactor codice — Step 15 funzionante".
- Esporta/copia anche il contenuto di Home Page settings -> Head/Footer e
  del Code Embed Step 13, oltre agli Step 14/15 già disponibili.
- Eventualmente duplica il sito come ambiente di prova.
- Nessuna modifica al sito originale prima di avere un punto di ripristino.

FASE 1 — OSPITARE I FILE
- Crea un repository pubblico GitHub chiamato "portfolio-assets".
- Carica la CARTELLA assets/ mantenendo i percorsi indicati.
- In Settings > Pages > Build and deployment imposta Deploy from a branch,
  main e /(root).
- Aspetta il deploy e apri nel browser:
  https://USERNAME.github.io/portfolio-assets/assets/css/places.css
  https://USERNAME.github.io/portfolio-assets/assets/js/places.js
  Entrambi devono mostrare i file, non una pagina 404.
- Se non vuoi rendere pubblico il codice, scegli un hosting privato per le
  sorgenti, ricordando però che CSS/JS consegnati al browser sono comunque leggibili.

FASE 2 — MIGRARE PLACES (solo una funzione alla volta)
- Su una COPIA del sito:
  1. Nell'attuale Embed Step 14 sostituisci l'intero contenuto con
     webflow-html/places_solo_html.txt. Attenzione: NON eliminare l'HTML.
  2. In Site settings > Custom code > Head aggiungi SOLO il link places.css.
  3. In Site settings > Custom code > Footer aggiungi SOLO lo script places.js.
  4. Non lasciare la copia originale dello script dentro l'Embed Step 14,
     altrimenti rischi di inizializzare due volte.
  5. Pubblica solo sulla staging .webflow.io, testa apertura PLACES,
     tre selezioni e BACK TO THE HUB; verifica anche WORK e SOUND.
  6. Se qualcosa non funziona: ripristina Embed originale e rimuovi i due
     riferimenti esterni, oppure ripristina il backup.

FASE 3 — MIGRARE TRAVEL JOURNAL
- Solo quando PLACES e' stato validato e salvato.
  1. Sostituisci il codice Embed Step 15 con
     webflow-html/journal_solo_html.txt.
  2. Aggiungi link journal.css al Head (dopo places.css).
  3. Aggiungi script journal.js al Footer (dopo places.js).
  4. Pubblica staging. Testa OPEN FIELD NOTES, NEXT ENTRY, BACK e ESC,
     scroll progress e accessibilità da tastiera.
  5. Riprova i mondi WORK, SOUND e PLACES.

DOPO IL TEST
- Ricorda: il Loader e gli script non vanno caricati due volte.
- Il JavaScript esterno va mantenuto nell'ordine places.js, journal.js.
- Per forzare un aggiornamento degli asset, incrementa ?v=1 -> ?v=2.
- Non spostare o minificare gli Step 1–13 a memoria.
- Le immagini Webflow e la struttura visuale del Designer non cambiano.

SICUREZZA
- Non pubblicare API key, password, token o dati sensibili in repository
  pubblici o nel codice frontend.
- Il pacchetto non ha modificato il tuo sito Webflow; e' preparazione locale.
